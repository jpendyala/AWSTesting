#import moto
import boto3
#from moto import mock_rds2
import pprint


pp = pprint

lamdba_clnt = boto3.client('lambda','us-east-1')

#@mock_lambda

class LambdaCreateTest:
    response = lamdba_clnt.create_function(
        FunctionName='string',
        Runtime='python3.6',
        Role='arn:aws:iam::030703475290:role/lambda_basic_execution',
        Handler='string',
        Code={
            'S3Bucket': 'pendyala4-bucket',
            'S3Key': 'create_simple_lambda.py'
        },
        Description='string',
        Timeout=10,
        MemorySize=128,
        Publish=False
    )